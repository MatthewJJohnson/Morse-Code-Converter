#include "BST.h"
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 121; Lab Section 1
* Programming Assignment: PA6
* Date:   10/21/2016
* Colloaborator(s):
* Description: This program creates a binary search tree and fills the tree with morse code.
This program then converts an entire text file to morse code, regardless of input or size.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/


//BST constructor
//POST: files are closed
//PRE: files exist
//copies the entire file from morsetable.txt.
//splits chracters and morse strings
//constructs the entire tree
BST::BST()
{
	mpRoot = nullptr;
	mInputStream.open("MorseTable.txt");
	int i = 0;
	while (i < 39)
	{
		char  newchar = '\0';
		string eatnewline = "";
		string newstring = "";
		getline(mInputStream, newstring, ' ');
		newchar = newstring[0];
		getline(mInputStream, newstring);
	//	getline(mInputStream, eatnewline); not needed
		insert(newchar, newstring);
		i++;
	}
	mInputStream.close();
}

//getter, gets the root pointer
Node * BST::getRoot() const
{
	return mpRoot;
}

// read the parameter type from right-to-left;
// newRoot is a constant pointer to a Node. This means
// the contents of newRoot can't be modified, but
// the Node can be modified!
void BST::setRoot(Node * const newRoot)
{
	mpRoot = newRoot;
}

//PRE: private insert function must exist, files must be open in constructor
void BST::insert(const char &newEnglishCharacter,
	const string &newMorseString)
{
	insert(this->mpRoot, newEnglishCharacter, newMorseString);
}

//private, uses recursion
//pre: public insert is called
//post: call stack is returned to its enter state
void BST::insert(Node *& pTree, const char &newEnglishCharacter,
		const string &newMorseString) //pTree is a reference to a pointer to a node
													//since it is a reference to a pointer, changes will be retained outside of this function. The reference replaces a double star
{
	if (pTree == nullptr)//base case
	{
		//making node
		Node *pMem = nullptr;
		pMem = new Node(newEnglishCharacter, newMorseString);
		//connecting to tree
		pTree = pMem;
	}
	else if (newEnglishCharacter > pTree->getEnglishCharacter())//direction goes right in the tree
	{
		insert(pTree->getRight(), newEnglishCharacter, newMorseString);
	}
	else if (newEnglishCharacter < pTree->getEnglishCharacter())//direction goes left in the tree
	{
		insert(pTree->getLeft(), newEnglishCharacter, newMorseString);
	}
	else //newdata == current node's data
	{
		cout << "Tried to insert a Duplicate" << endl;
	}
}

//PRE: private print function must exist
//sends the root into the private print function
void BST::inOrderPrintTraversal() 
{
	inOrderPrintTraversal(this->mpRoot);
}

//pre: public insert is called
//post: call stack is returned to enter state
//the entire tree is traversed and printed both the character and string it holds
void BST::inOrderPrintTraversal(Node *pTree) 
{
	//base case
	if (pTree != nullptr) //first null pointer will be all the way left
	{
		//1. go left
		inOrderPrintTraversal(pTree->getLeft());
		//2. process the node (print stuff)
		cout << pTree->getEnglishCharacter() << ":" << pTree->getMorseString() << endl;
		//3. go right
		inOrderPrintTraversal(pTree->getRight());
	}
}
//PRE: private search function must exist
//sends the root into the private search function
void BST::inOrderSearch()
{
	inOrderSearch(this->mpRoot);
}

//pre: public search was called
//post: search was called
//this extracts a string from the convert file.
//the string is parced character by character
//all characters are made uppercase
void BST::inOrderSearch(Node *pTree)
{
	mInputStream.open("Convert.txt");
	while (!mInputStream.eof())
	{
		int i = 0;
		char  newchar1 = '\0';
		string newstring = "";
		getline(mInputStream, newstring);

		int length = newstring.length();
		while (i < length)
		{
			newchar1 = newstring[i];
			newchar1 = toupper(newchar1);
			SearchPrint(pTree, newchar1);
			i++;
		}
	}
	mInputStream.close();
}

//pre: public and private search functions are called
//pre: convert.txt is open
//post: call stack is returned to enter state
//the entire tree is traversed and printed morse string it holds
void BST::SearchPrint(Node *pTree, char newchar)
{
	if (pTree != nullptr) //first null pointer will be all the way left
	{
		//1. go left
		SearchPrint(pTree->getLeft(), newchar);
		//2. process the node (print stuff)
		if (pTree->getEnglishCharacter() == newchar)
		{
			cout << pTree->getMorseString() << " ";
		}
		//3. go right
		SearchPrint(pTree->getRight(), newchar);
	}
}
