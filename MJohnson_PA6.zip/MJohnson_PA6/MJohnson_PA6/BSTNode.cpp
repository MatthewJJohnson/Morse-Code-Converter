#include "BSTNode.h"
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 121; Lab Section 1
* Programming Assignment: PA6
* Date:   10/21/2016
* Colloaborator(s):
* Description: This program creates a binary search tree and fills the tree with morse code.
This program then converts an entire text file to morse code, regardless of input or size.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/


//destructor with default arguments, required by andy for this PA
Node::Node(char newEnglishCharacter, string newMorseString)
{
	mMorseString = newMorseString;
	mEnglishCharacter = newEnglishCharacter; // will be on heap
	mpLeft = nullptr;
	mpRight = nullptr;
}

//getter, get left leaflet
Node *& Node::getLeft() //returns a reference to a pointer
{
	return mpLeft;
}

//getter, get right leaflet
Node *& Node::getRight() //returns a reference to a pointer
{
	return mpRight;
}

//getter, get the english character string from the node
char Node::getEnglishCharacter() const
{
	return mEnglishCharacter;
}

//getter, get the morse string from the node
string Node::getMorseString() const
{
	return mMorseString;
}

//setter, set left leaflet pointer
void Node::setLeft(Node * const newLeft)
{
	mpLeft = newLeft;
}

//setter, set right leaflet pointer
void Node::setRight(Node * const newRight)
{
	mpRight = newRight;
}





