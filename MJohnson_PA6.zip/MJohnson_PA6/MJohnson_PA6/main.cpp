#include "BST.h"
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 121; Lab Section 1
* Programming Assignment: PA6
* Date:   10/21/2016
* Colloaborator(s):
* Description: This program creates a binary search tree and fills the tree with morse code.
				This program then converts an entire text file to morse code, regardless of input or size.
				Found in this solution and with the assignment submission is the bst diagram for this PA.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/

int main(void)
{
	BST ConversionTree; 

	cout << "Printing the Tree...\n" << endl;
	ConversionTree.inOrderPrintTraversal(); //prints the tree diagram by walking through the diagram. (where G is the top node of the tree)
	cout << "\nDone...\n" << endl;

	cout << "Converting an English String from Convert.txt...\n" << endl;
	ConversionTree.inOrderSearch(); //converts text file
	cout << "\nDone...\n" << endl;

	return 0; //main returns 0
}