#pragma once
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 121; Lab Section 1
* Programming Assignment: PA6
* Date:   10/21/2016
* Colloaborator(s):
* Description: This program creates a binary search tree and fills the tree with morse code.
This program then converts an entire text file to morse code, regardless of input or size.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/
#include <iostream>
#include <fstream>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::istream;
using std::fstream;
using std::ifstream;
using std::ofstream;
using std::string;
using std::ios;

class Node
{
public:
	//construct
	Node(char newEnglishCharacter = '\0', string newMorseString = "");

	//get
	char getEnglishCharacter() const;
	string getMorseString() const;
	Node *& getLeft();
	Node *& getRight();

	//set
	void setLeft(Node * const newLeft);
	void setRight(Node * const newRight);

private://data members
	char mEnglishCharacter;
	string mMorseString;
	Node *mpLeft;
	Node *mpRight;
};
