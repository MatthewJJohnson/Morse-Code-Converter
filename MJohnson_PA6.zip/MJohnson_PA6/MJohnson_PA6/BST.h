#pragma once
/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 121; Lab Section 1
* Programming Assignment: PA6
* Date:   10/21/2016
* Colloaborator(s):
* Description: This program creates a binary search tree and fills the tree with morse code.
This program then converts an entire text file to morse code, regardless of input or size.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/
#include "BSTNode.h"
#include <iostream>
#include <fstream>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::istream;
using std::fstream;
using std::ifstream;
using std::ofstream;
using std::string;
using std::ios;

class BST
{
public:
	BST();//constructor

	//getter
	Node *getRoot() const;

	//setter
	void setRoot(Node * const newRoot);

	//public functions
	void insert(const char &newEnglishCharacter, const string &newMorseString);
	void inOrderPrintTraversal();
	void inOrderSearch();
	void SearchPrint(Node *pTree, char newchar);

private://private data members and private functions
	ifstream mInputStream;
	Node *mpRoot;
	void insert(Node *& pTree, const char &newEnglishCharacter, const string &newMorseString);
	void inOrderPrintTraversal(Node *pTree);
	void inOrderSearch(Node *pTree);
};